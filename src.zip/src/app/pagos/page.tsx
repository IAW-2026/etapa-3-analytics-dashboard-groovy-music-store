"use client";
import TarjetaMetrica from "@/components/TarjetaMetrica";
import GraficoLineas from "@/components/GraficoLineas";
import GraficoBarras from "@/components/GraficoBarras";
import GraficoDonut from "@/components/GraficoDonut";
import { usePolling } from "@/hooks/usePolling";
import type { Metrica, DistribucionEstado } from "@/lib/types";

const num = (v: unknown): number | null =>
  typeof v === "number" && !isNaN(v) ? v : null;
const fmtMoneda = (v: unknown) => {
  const n = num(v);
  return n === null ? "—" : `$${n.toLocaleString("es-AR")}`;
};
const fmtNum = (v: unknown) => {
  const n = num(v);
  return n === null ? "—" : n.toLocaleString("es-AR");
};
const fmtPct = (v: unknown) => {
  const n = num(v);
  return n === null ? "—" : `${n.toFixed(1)}%`;
};

type DatosPagos = {
  resumen: any;
  serieArr: any[];
};

export default function PagosPage() {
  const { datos, cargando, ultimaActualizacion } = usePolling<DatosPagos>(
    "/api/datos-pagos",
    30000
  );

  const resumen = datos?.resumen;
  const serieArr = datos?.serieArr ?? [];

  const serieFormateada = serieArr.map((p: any) => {
    const fecha = p.fecha ?? p.dia;
    const d = new Date(fecha);
    const total = (p.pagado ?? 0) + (p.acreditado ?? 0) + (p.pendiente ?? 0) + (p.fallido ?? 0) + (p.reembolsado ?? 0);
    return {
      fecha: `${String(d.getDate()).padStart(2, "0")} ${d.toLocaleString("es-AR", { month: "short" })}`,
      cantidad: total,
    };
  });

  const metricas: Metrica[] = [
    {
      titulo: "Volumen transado",
      valor: fmtMoneda(resumen?.volumenTotal),
      variacion: 0,
      tendencia: "flat",
      subtitulo: resumen?.totalTransacciones != null
        ? `${resumen.totalTransacciones} transacciones`
        : "sin datos",
    },
    {
      titulo: "Tasa de aprobación",
      valor: fmtPct(resumen?.porcentajes?.aprobadas),
      variacion: 0,
      tendencia: "flat",
      subtitulo: resumen?.porcentajes?.rechazadas != null
        ? `${fmtPct(resumen.porcentajes.rechazadas)} rechazadas`
        : undefined,
    },
    {
      titulo: "Fondos retenidos",
      valor: fmtMoneda(resumen?.fondos?.retenidos),
      variacion: 0,
      tendencia: "flat",
      subtitulo: "pendientes de liberación",
    },
    {
      titulo: "Fondos liberados",
      valor: fmtMoneda(resumen?.fondos?.liberados),
      variacion: 0,
      tendencia: "flat",
      subtitulo: "acreditados a vendedores",
    },
  ];

  const porEstado: DistribucionEstado[] = resumen?.transacciones
    ? [
        { estado: "Aprobadas", cantidad: resumen.transacciones.aprobadas ?? 0 },
        { estado: "Pendientes", cantidad: resumen.transacciones.pendientes ?? 0 },
        { estado: "Rechazadas", cantidad: resumen.transacciones.rechazadas ?? 0 },
        { estado: "Reembolsadas", cantidad: resumen.transacciones.reembolsadas ?? 0 },
      ]
    : [];

  const fondos: DistribucionEstado[] = resumen?.fondos
    ? [
        { estado: "Retenidos", cantidad: Math.round(resumen.fondos.retenidos ?? 0) },
        { estado: "Liberados", cantidad: Math.round(resumen.fondos.liberados ?? 0) },
      ]
    : [];

  return (
    <main className="min-h-screen bg-background">
      <header className="bg-secondary text-secondary-foreground">
        <div className="max-w-7xl mx-auto px-6 py-4 flex items-center justify-between">
          <div className="flex items-center gap-3">
            <div className="h-8 w-8 rounded-md bg-primary flex items-center justify-center font-display font-bold text-sm text-primary-foreground">
              G
            </div>
            <span className="font-display font-semibold tracking-tight">Groovy Analytics</span>
          </div>
          <nav className="flex items-center gap-6 text-sm">
            <a href="/" className="hover:text-primary transition-colors">Resumen</a>
            <a href="/ordenes" className="hover:text-primary transition-colors">Órdenes</a>
            <a href="/ventas" className="hover:text-primary transition-colors">Ventas</a>
            <a href="/pagos" className="text-primary font-medium">Pagos</a>
            <a href="/envios" className="hover:text-primary transition-colors">Envíos</a>
          </nav>
        </div>
      </header>

      <div className="max-w-7xl mx-auto px-6 py-10">
        <div className="mb-10">
          <p className="text-xs uppercase tracking-[0.2em] text-primary font-display font-medium mb-2">Payments</p>
          <h1 className="text-4xl font-serif font-light tracking-tight">Análisis de pagos</h1>
          <p className="text-sm text-muted-foreground mt-2">
            Métricas financieras y estado de transacciones · Actualizado {ultimaActualizacion || "cargando..."}
          </p>
        </div>

        {cargando && !datos && (
          <p className="text-sm text-muted-foreground text-center py-20">Cargando datos...</p>
        )}

        {datos && (
          <>
            <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-4 mb-6">
              {metricas.map((m) => (
                <TarjetaMetrica key={m.titulo} metrica={m} />
              ))}
            </div>

            <div className="grid grid-cols-1 lg:grid-cols-2 gap-4 mb-6">
              <GraficoLineas
                titulo="Transacciones por día"
                subtitulo="Últimos 30 días"
                datos={serieFormateada}
                labelY="Transacciones"
              />
              <GraficoDonut
                titulo="Distribución por estado"
                subtitulo={`Total: ${fmtNum(resumen?.totalTransacciones)}`}
                datos={porEstado}
              />
            </div>

            <div className="grid grid-cols-1 lg:grid-cols-2 gap-4">
              <GraficoBarras
                titulo="Estado de fondos"
                subtitulo="Retenidos vs liberados (en pesos)"
                datos={fondos}
                color="var(--secondary)"
              />
              <GraficoBarras
                titulo="Transacciones por estado"
                subtitulo={`Total: ${fmtNum(resumen?.totalTransacciones)}`}
                datos={porEstado}
              />
            </div>
          </>
        )}
      </div>
    </main>
  );
}